/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication34;

//import Izfile21;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

public class Okno implements ActionListener {

public Okno() {
initComponents();
}

private JFrame viewForm;

private void initComponents() {
viewForm = new JFrame("Окошечко");
viewForm.setSize(400, 400);
viewForm.setVisible(true);
viewForm.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);

JButton but = new JButton("Начать");
but.setVisible(true);
but.setLocation(110, 160);
but.setSize(165, 50);

JButton button = new JButton("Подробнее..");
button.setVisible(true);
button.setLocation(220, 320);
button.setSize(165, 50);
button.addActionListener(new ActionListener() {


public void actionPerformed(ActionEvent e) {
    
new xaxa("Текст", 400, 400);

}

});
viewForm.getContentPane().add(button);
viewForm.getContentPane().add(new JLabel());
viewForm.getContentPane().add(but);
viewForm.getContentPane().add(new JLabel());
}

public void actionPerformed(ActionEvent action) {
}

public static void main(String[] args) {
SwingUtilities.invokeLater(new Runnable() {
public void run() {
new Okno();
}
});
}
}